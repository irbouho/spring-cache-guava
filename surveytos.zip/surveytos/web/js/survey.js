$(document).ready(function() {
	// pagination button
	$("button[value='PREVIOUS']").click(function () {
		var sectionId = $("#sectionId").val() - 1;
		window.location = '/survey/' + sectionId;
	});
});