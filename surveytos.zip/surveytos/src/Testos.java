import com.hakima.config.AppConfig;
import com.hakima.dao.SurveyDao;
import com.hakima.model.Questionnaire;
import com.hakima.model.Survey;
import com.hakima.model.SurveyExecution;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.expression.spel.standard.SpelExpressionParser;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class Testos {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);

		SurveyDao dao = ctx.getBean(SurveyDao.class);
		SpelExpressionParser parser = ctx.getBean(SpelExpressionParser.class);

		Survey survey = dao.getByCode("sample");
		Questionnaire questionnaire = new Questionnaire();
		questionnaire.getAnswers().put("sports", "football");
		questionnaire.setSectionId(4);

		SurveyExecution execution = new SurveyExecution(survey, questionnaire, parser);

		ctx.close();
	}

}