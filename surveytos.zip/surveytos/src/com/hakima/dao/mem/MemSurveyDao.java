package com.hakima.dao.mem;

import com.google.common.collect.ImmutableMap;
import com.hakima.dao.SurveyDao;
import com.hakima.model.IntroductionSurveySection;
import com.hakima.model.QuestionSurveySection;
import com.hakima.model.SummarySurveySection;
import com.hakima.model.Survey;
import org.springframework.stereotype.Repository;

import static com.google.common.collect.ImmutableMap.of;
import static com.hakima.model.CheckBoxQuestion.newCheckBox;
import static com.hakima.model.ComboBoxQuestion.newComboBox;
import static com.hakima.model.DateQuestion.newDate;
import static com.hakima.model.ListBoxQuestion.newListBox;
import static com.hakima.model.NumberQuestion.newInt;
import static com.hakima.model.Option.newOption;
import static com.hakima.model.RadioQuestion.newRadio;
import static com.hakima.model.TextAreaQuestion.newTextArea;
import static com.hakima.model.TextQuestion.newText;

/**
 * @author irbouho
 * @since 1.0.0
 */
@Repository
public class MemSurveyDao implements SurveyDao {

	private final ImmutableMap<String, Survey> surveys;

	public MemSurveyDao() {
		surveys = of("sample", createSampleSurvey());
	}

	@Override
	public Survey getByCode(String code) {
		return surveys.get(code);
	}

	private Survey createSampleSurvey() {
		Survey survey = new Survey();
		survey.setCode("sample");
		survey.setName("Sample Survey");
		survey.setShowMenu(true);
		survey.setShowProgress(true);
		survey.setAllowPrevious(true);

		IntroductionSurveySection intro = new IntroductionSurveySection();
		intro.setCode("welcome");
		intro.setName("Welcome to this survey");
		intro.setShortName("Welcome");
		intro.setHint("All your personal data belongs to us");
		intro.setComments("Please provide accurate data. This will help us know more about you.");
		survey.addSection(intro);

		QuestionSurveySection section = new QuestionSurveySection();
		section.setCode("personal");
		section.setName("Personal Information");
		section.setShortName("Personal Info.");
		section.setHint("All your personal data belongs to us");

		section.addQuestion(newText("firstName", "First Name", true, 10, "First name id required field."));
		section.addQuestion(newText("lastName", "Last Name", true, 10, null));
		section.addQuestion(newInt("age", "Age", 0, 120, true, "Don't be shy about telling us your age."));
		section.addQuestion(newDate("birthDate", "Birth Date", true, "Don't be shy about telling us your age."));
		section.addQuestion(newComboBox("gender", "Gender", true, "200px", "Oh boy!",
				newOption(0, "male", "Male", null, false),
				newOption(1, "female", "Female", null, false)
		));
		survey.addSection(section);

		section = new QuestionSurveySection();
		section.setCode("contact");
		section.setName("Contact Information");
		section.setShortName("Contact Info.");
		section.setHint("This is important");
		section.addQuestion(newTextArea("address", "Address", true, 5, "75%", 1000, "Free form text"));
		survey.addSection(section);

		section = new QuestionSurveySection();
		section.setCode("sports");
		section.setName("Favorite Sports");
		section.setShortName("Favorite Sports");
		section.setHint("Everyone likes sports");
		section.addQuestion(newRadio("sports", "Do you like sports", true, "We're sure you do",
				newOption(0, "football", "Football", "American football", false),
				newOption(1, "soccer", "Soccer", "European football", false),
				newOption(2, "$$other$$_sports", "Other", "other type of sports", true)
		));
		survey.addSection(section);

		section = new QuestionSurveySection();
		section.setCode("food");
		section.setName("Favorite Food");
		section.setShortName("Favorite Food");
		section.setHint("How about some food information now");

		section.addQuestion(newListBox("drinks", "Drinks", true, true, 10, "200px", "What do you like to drink while watching sports...",
				newOption(0, "tea", "Tea", null, false),
				newOption(1, "coffee", "Coffee", null, false),
				newOption(2, "coke", "Coca Cola", null, false),
				newOption(3, "pepsi", "Pepsi Cola", null, false),
				newOption(4, "water", "Water", null, false)
		));
		section.addQuestion(newCheckBox("food", "Food", true, "What do you like to eat",
				newOption(0, "wings", "Chicken wings", null, false),
				newOption(1, "pizza", "Pizza", null, false),
				newOption(2, "hotdogs", "Hot dogs", null, false),
				newOption(3, "popcorn", "Popcorn", null, false),
				newOption(4, "$$other$$_food", "Other", null, true)
		));
		section.addQuestion(newRadio("clothes", "Clothes", true, "What size to wear",
				newOption(0, "sp", "Small", null, false),
				newOption(1, "mm", "Medium", null, false),
				newOption(2, "l", "Large", null, false),
				newOption(3, "xl", "Extra Large", null, false)
		));
		survey.addSection(section);

		SummarySurveySection summary = new SummarySurveySection();
		summary.setCode("summary");
		summary.setName("Thank you");
		summary.setShortName("Summary");
		summary.setHint("All your personal data belongs to us");
		summary.setComments("Thank you for providing all this information about yourself.");
		survey.addSection(summary);

		return survey;
	}

}