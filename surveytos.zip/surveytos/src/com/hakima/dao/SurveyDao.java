package com.hakima.dao;

import com.hakima.model.Survey;

/**
 * @author irbouho
 * @since 1.0.0
 */
public interface SurveyDao {

	Survey getByCode(String code);

}