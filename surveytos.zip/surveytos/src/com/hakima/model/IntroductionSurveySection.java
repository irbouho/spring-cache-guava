package com.hakima.model;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class IntroductionSurveySection extends AbstractSurveySection {

	public IntroductionSurveySection() {
		super(SectionType.INTRODUCTION);
	}

}