package com.hakima.model;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @author irbouho
 * @since 1.0.0
 */
public abstract class AbstractMultiValueQuestion extends AbstractQuestion {

	private final Collection<Option> options = new ArrayList<>();
	private String width = "100%";

	protected AbstractMultiValueQuestion(QuestionType type) {
		super(type);
	}

	public Collection<Option> getOptions() {
		return options;
	}

	public void setOptions(Collection<Option> options) {
		this.options.clear();
		this.options.addAll(options);
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

}