package com.hakima.model;

/**
 * @author irbouho
 * @since 1.0.0
 */
public enum QuestionType {

	TEXT,
	TEXTAREA,
	INT,
	DATE,
	RADIO,
	CHECKBOX,
	COMBOBOX,
	LISTBOX,
	MATRIX,

}