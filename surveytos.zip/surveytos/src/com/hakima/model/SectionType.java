package com.hakima.model;

/**
 * @author irbouho
 * @since 1.0.0
 */
public enum SectionType {

	INTRODUCTION,
	QUESTION,
	SUMMARY

}