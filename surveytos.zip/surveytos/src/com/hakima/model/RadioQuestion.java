package com.hakima.model;

import static java.util.Arrays.asList;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class RadioQuestion extends AbstractMultiValueQuestion {

	public RadioQuestion() {
		super(QuestionType.RADIO);
	}

	public static RadioQuestion newRadio(String code, String name, boolean required,
										 String hint,
										 Option... options) {
		RadioQuestion q = new RadioQuestion();
		q.setCode(code);
		q.setName(name);
		q.setRequired(required);
		q.setHint(hint);
		q.setOptions(asList(options));
		return q;
	}

}