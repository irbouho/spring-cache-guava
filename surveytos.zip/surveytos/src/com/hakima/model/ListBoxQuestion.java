package com.hakima.model;

import static java.util.Arrays.asList;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class ListBoxQuestion extends AbstractMultiValueQuestion {

	private boolean multiSelect = false;
	private int size;

	public ListBoxQuestion() {
		super(QuestionType.LISTBOX);
	}

	public boolean isMultiSelect() {
		return multiSelect;
	}

	public void setMultiSelect(boolean multiSelect) {
		this.multiSelect = multiSelect;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public static ListBoxQuestion newListBox(String code, String name, boolean required,
											 boolean multiSelect,
											 int size, String width,
											 String hint,
											 Option... options) {
		ListBoxQuestion q = new ListBoxQuestion();
		q.setCode(code);
		q.setName(name);
		q.setRequired(required);
		q.setMultiSelect(multiSelect);
		q.setSize(size);
		q.setWidth(width);
		q.setHint(hint);
		q.setOptions(asList(options));
		return q;
	}

}