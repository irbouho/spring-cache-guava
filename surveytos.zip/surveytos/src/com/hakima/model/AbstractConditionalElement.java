package com.hakima.model;

import org.springframework.expression.Expression;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * @author irbouho
 * @since 1.0.0
 */
public abstract class AbstractConditionalElement implements Serializable {

	private String condition;

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public boolean evaluate(SpelExpressionParser parser, Map<String, Object> context) {
		boolean result = true;
		if (StringUtils.hasText(condition)) {
			Expression expression = parser.parseExpression(condition);
			Object args = this;
			if (context != null) {
				// defensive copy
				Map<String, Object> map = new HashMap<>(context);
				// add this
				map.put("this", this);
				args = map;
			}

			result = expression.getValue(args, Boolean.class);
		}

		return result;
	}

}