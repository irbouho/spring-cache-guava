package com.hakima.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class QuestionSurveySection extends AbstractSurveySection {

	private List<AbstractQuestion> questions = new ArrayList<>();

	public QuestionSurveySection() {
		super(SectionType.QUESTION);
	}

	public List<? extends AbstractQuestion> getQuestions() {
		return questions;
	}

	public void setQuestions(List<AbstractQuestion> questions) {
		this.questions.clear();
		this.questions.addAll(questions);
	}

	public void addQuestion(AbstractQuestion question) {
		this.questions.add(question);
	}

}