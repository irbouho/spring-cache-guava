package com.hakima.model;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class NumberQuestion extends AbstractQuestion {

	private int min = Integer.MIN_VALUE;
	private int max = Integer.MAX_VALUE;

	public NumberQuestion() {
		super(QuestionType.INT);
	}

	public int getMin() {
		return min;
	}

	public void setMin(int min) {
		this.min = min;
	}

	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}

	public static NumberQuestion newInt(String code, String name,
										int min, int max,
										boolean required,
										String hint) {
		NumberQuestion q = new NumberQuestion();
		q.setCode(code);
		q.setName(name);
		q.setMin(min);
		q.setMax(max);
		q.setRequired(required);
		q.setHint(hint);
		return q;
	}

}