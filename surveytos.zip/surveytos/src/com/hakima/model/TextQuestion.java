package com.hakima.model;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class TextQuestion extends AbstractQuestion {

	private int maxLength;
	private String width = "50%";

	public TextQuestion() {
		super(QuestionType.TEXT);
	}

	protected TextQuestion(QuestionType type) {
		super(type);
	}

	public int getMaxLength() {
		return maxLength;
	}

	public void setMaxLength(int maxLength) {
		this.maxLength = maxLength;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public static TextQuestion newText(String code, String name, boolean required, int maxLength, String hint) {
		TextQuestion q = new TextQuestion();
		q.setCode(code);
		q.setName(name);
		q.setRequired(required);
		q.setMaxLength(maxLength);
		q.setHint(hint);
		return q;
	}

}