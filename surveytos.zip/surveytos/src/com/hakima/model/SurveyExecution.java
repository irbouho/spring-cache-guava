package com.hakima.model;

import org.springframework.expression.spel.standard.SpelExpressionParser;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.Collections.emptyList;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class SurveyExecution implements Serializable {

	private String code;
	private String name;
	private boolean showMenu;
	private boolean showProgress;
	private boolean allowPrevious;

	private int sectionId;

	private List<AbstractSurveySection> sections = new ArrayList<>();

	private List<AbstractQuestion> questions = new ArrayList<>();

	public SurveyExecution(Survey survey,
						   Questionnaire questionnaire,
						   SpelExpressionParser parser) {

		// evaluate and prepare execution data
		initSurvey(survey);

		initSections(survey, questionnaire, parser);

		initSectionId(questionnaire);

		initSection(survey, questionnaire, parser);
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	public boolean isShowMenu() {
		return this.showMenu;
	}

	public boolean isShowProgress() {
		return this.showProgress;
	}

	public boolean isAllowPrevious() {
		return this.allowPrevious;
	}

	public int getSectionId() {
		return sectionId;
	}

	@SuppressWarnings("unchecked")
	public <T extends AbstractSurveySection> List<T> getSections() {
		return (List<T>) sections;
	}

	@SuppressWarnings("unchecked")
	public <T extends AbstractSurveySection> T getSection() {
		return (T) sections.get(sectionId);
	}

	private void initSurvey(Survey survey) {
		this.code = survey.getCode();
		this.name = survey.getName();
		this.showMenu = survey.isShowMenu();
		this.showProgress = survey.isShowProgress();
		this.allowPrevious = survey.isAllowPrevious();
	}

	private void initSections(Survey survey,
							  Questionnaire questionnaire,
							  SpelExpressionParser parser) {
		// create the context
		Map<String, Object> context = new HashMap<>();
		context.put("survey", survey);
		context.put("questionnaire", questionnaire);

		// evaluate and add to sections
		for (AbstractSurveySection section : survey.getSections()) {

			if (section.evaluate(parser, context)) {
				this.sections.add(section);
			}
		}
	}

	private void initSectionId(Questionnaire questionnaire) {
		sectionId = questionnaire.getSectionId();

		if (sectionId < 0 || sectionId >= getSections().size()) {
			// reset to first section
			sectionId = 0;
			questionnaire.setSectionId(sectionId);
		}
	}

	private void initSection(Survey survey,
							 Questionnaire questionnaire,
							 SpelExpressionParser parser) {

		AbstractSurveySection section = getSection();
		switch (section.getType()) {
			case INTRODUCTION:
			case SUMMARY:
				this.questions = emptyList();
				break;
			case QUESTION:
				initQuestions(survey, (QuestionSurveySection) section, questionnaire, parser);
				break;
		}
	}

	private void initQuestions(Survey survey,
							   QuestionSurveySection section,
							   Questionnaire questionnaire,
							   SpelExpressionParser parser) {
		// create the context
		Map<String, Object> context = new HashMap<>();
		context.put("survey", survey);
		context.put("section", section);
		context.put("questionnaire", questionnaire);

		for (AbstractQuestion question : section.getQuestions()) {
			if (question.evaluate(parser, context)) {
				this.questions.add(question);
			}
		}
	}

}