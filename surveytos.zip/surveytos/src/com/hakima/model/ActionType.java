package com.hakima.model;

/**
 * @author irbouho
 * @since 1.0.0
 */
public enum ActionType {

	PROCEED,
	PREVIOUS,
	NEXT,
	SUBMIT,
	COMPLETE;

}