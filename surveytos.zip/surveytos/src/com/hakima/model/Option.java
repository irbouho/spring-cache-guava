package com.hakima.model;

import java.io.Serializable;

/**
 * @author irbouho
 * @since 1.0.0
 */
public class Option implements Serializable {

	private int sequenceId;
	private String code;
	private String name;
	private boolean other;
	private String hint;

	public int getSequenceId() {
		return sequenceId;
	}

	public void setSequenceId(int sequenceId) {
		this.sequenceId = sequenceId;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isOther() {
		return other;
	}

	public void setOther(boolean other) {
		this.other = other;
	}

	public String getHint() {
		return hint;
	}

	public void setHint(String hint) {
		this.hint = hint;
	}

	public static Option newOption(int sequenceId, String code, String name, String hint, boolean other) {
		Option o = new Option();
		o.setSequenceId(sequenceId);
		o.setCode(code);
		o.setName(name);
		o.setHint(hint);
		o.setOther(other);
		return o;
	}

}